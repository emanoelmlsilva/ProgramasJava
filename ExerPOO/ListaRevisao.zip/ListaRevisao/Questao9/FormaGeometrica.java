public interface FormaGeometrica{

    public double calculaPerimetro();
    public double calculaArea();
}