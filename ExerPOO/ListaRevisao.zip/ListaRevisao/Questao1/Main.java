public class Main{
    public static void main(String[]args){
        Scanner input = new Scanner(System.in);
        Retangulo r1 = new Retangulo(4,6);
        Retangulo r2 = new Retangulo(4,2);            
        System.out.println(r1.toString());
        System.out.println(r2.toString());
    }
}